iio_attr  -c one-bit-adc-dac voltage9 raw 1
iio_attr  -c one-bit-adc-dac voltage8 raw 1
iio_attr  -c one-bit-adc-dac voltage7 raw 1
iio_attr  -c one-bit-adc-dac voltage6 raw 1
iio_attr  -c one-bit-adc-dac voltage0 raw 1
iio_attr  -c one-bit-adc-dac voltage1 raw 1
iio_attr  -c one-bit-adc-dac voltage2 raw 1
iio_attr  -c one-bit-adc-dac voltage3 raw 1
